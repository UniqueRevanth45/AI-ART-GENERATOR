import requests
API_URL=""
HEADERS ={
    "Authorization":"Bearer YOUR_HUGGING_FACE_API"
}
def generate_image(prompt):
    response=requests.post(
        API_URL,
        headers=HEADERS,
        json={"inputs": prompt}
    )
    if response.status_code !=200:
        raise Exception("Image generation failed")
    return response.content