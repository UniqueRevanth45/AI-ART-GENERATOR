from flask import Flask, request,send_file,render_template
from generate import generate_image
from io import BytesIO

app = Flask(__name__)
 
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    prompt = request.form.get('prompt')
    image_bytes = generate_image(prompt)
    return send_file(BytesIO(image_bytes), mimetype='image/png')
if __name__ == '__main__':
    app.run(debug=True)